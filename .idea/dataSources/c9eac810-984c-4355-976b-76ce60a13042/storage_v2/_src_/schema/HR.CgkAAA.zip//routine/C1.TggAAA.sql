create PROCEDURE C1  AS 

ignore boolean;

 BEGIN NULL;
htp.prn('
');
htp.prn(' 
');
htp.prn('
<html>
<head>
<title>C1</title>
<body>

<table border="1">
<tr>
<td>ID USLUGI</td>		<td>ID PLATNOSCI</td>		<td>ILOSC</td></tr>

  ');
 FOR I IN (
SELECT IdPracownika , IdProduktu, Sum(Ilosc) AS ILOSC FROM p_sprzedaz group BY rollup
(IdPracownika,IdProduktu)

) LOOP 
htp.prn('
				<tr>
					<td>');
htp.prn( I.idPRACOWNIKA );
htp.prn('      </td>    
		<td>');
htp.prn( I.idproduktu );
htp.prn('      </td>    
			<td>');
htp.prn( I.ILOSC );
htp.prn('      </td>  
</tr>
			
				');
 END LOOP; 
htp.prn('
				</table>

</body>
</html>



');
 END;
/

