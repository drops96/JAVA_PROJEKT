package podstawowy;

import javax.swing.*;
import java.awt.event.*;

public class LOGIN extends JDialog {
    private JPanel contentPane;
    private JButton buttonOK;
    private JFormattedTextField formattedTextField1;
    private JFormattedTextField formattedTextField2;
    private  String adresIP;
    private  String nick;

    private LOGIN() {
        setContentPane(contentPane);
        setModal(true);
        getRootPane().setDefaultButton(buttonOK);

        buttonOK.addActionListener(e -> onOK());


        formattedTextField1.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                adresIP=formattedTextField1.getText();
                super.focusLost(e);
            }
        });

        formattedTextField2.addFocusListener(new FocusAdapter() {
            @Override
            public void focusLost(FocusEvent e) {
                nick=formattedTextField2.getText();
                super.focusLost(e);
            }
        });

    }

    private void onOK() {

        new Thread(() -> {
            try {
                TicTaToeClient.main(new String[] {adresIP,nick});
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();

    }

    public static void main(String[] args) {
        LOGIN dialog = new LOGIN();
        dialog.pack();
        dialog.setVisible(true);

    }
}
