create PROCEDURE PO1  AS 
 BEGIN NULL;
htp.prn('
');
htp.prn(' 
<html>
<head>
<title>SIEC ZAKLADOW POGRZEBOWYCH</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" >

<style>

body{text-align:center;
	 font-family: "Arial";}
#ft{clear:both;}


#doc,#doc2,#doc3,.yui-t1,.yui-t2,.yui-t3,.yui-t4,.yui-t5,.yui-t6,.yui-t7 {
	margin:auto;text-align:left;
	width:57.69em;*width:56.3em;min-width:750px;}

#doc2 {
	width:73.074em;*width:71.313em;min-width:950px;}

#doc3 {
	margin:auto 10px;
	width:auto;}
	



	.yui-b{position:relative;}
	.yui-b{_position:static;} 
	#yui-main .yui-b{position:static;} 

#yui-main {width:100%;}
.yui-t1 #yui-main,
.yui-t2 #yui-main,
.yui-t3 #yui-main{float:right;margin-left:-25em;/* IE: preserve layout at narrow widths */}

.yui-t4 #yui-main,
.yui-t5 #yui-main,
.yui-t6 #yui-main{float:left;margin-right:-25em;/* IE: preserve layout at narrow widths */}

.yui-t1 .yui-b {
	float:left;
    width:12.3207em;*width:12.0106em;}
.yui-t1 #yui-main .yui-b{
    margin-left:13.3207em;*margin-left:13.0106em;
}

.yui-t2 .yui-b {
	float:left;
    width:13.8456em;*width:13.512em;}
.yui-t2 #yui-main .yui-b {
    margin-left:14.8456em;*margin-left:14.512em;
}

.yui-t3 .yui-b {
	float:left;
    width:23.0759em;*width:22.52em;}
.yui-t3 #yui-main .yui-b {
    margin-left:24.0759em;*margin-left:23.52em;
}

.yui-t4 .yui-b {
	float:right;
    width:13.8456em;*width:13.512em;}
.yui-t4 #yui-main .yui-b {
    margin-right:14.8456em;*margin-right:14.512em;
}

.yui-t5 .yui-b {
	float:right;
    width:18.4608em;*width:18.016em;}
.yui-t5 #yui-main .yui-b {
    margin-right:19.4608em;*margin-right:19.016em;
}

.yui-t6 .yui-b {
	float:right;
    width:23.0759em;*width:22.52em;}
.yui-t6 #yui-main .yui-b {
    margin-right:24.0759em;*margin-right:23.52em;
}

.yui-t7 #yui-main .yui-b {
	display:block;margin:0 0 1em 0;
}
#yui-main .yui-b {float:none;width:auto;}
/* GRIDS (not TEMPLATES) */
.yui-g .yui-u, 
.yui-g .yui-g, 
.yui-gc .yui-u,
.yui-gc .yui-g .yui-u,
.yui-ge .yui-u, 
.yui-gf .yui-u{float:right;display:inline;}
.yui-g div.first, 
.yui-gc div.first,
.yui-gc div.first div.first,
.yui-gd div.first, 
.yui-ge div.first, 
.yui-gf div.first{float:left;}
.yui-g .yui-u, 
.yui-g .yui-g{width:49.1%;}
.yui-g .yui-g .yui-u,
.yui-gc .yui-g .yui-u {width:48.1%;}
.yui-gb .yui-u, 
.yui-gc .yui-u, 
.yui-gd .yui-u{float:left;margin-left:2%;*margin-left:1.895%;width:32%;}
.yui-gb div.first, 
.yui-gc div.first, 
.yui-gd div.first{margin-left:0;}
.yui-gc div.first, 
.yui-gd .yui-u{width:66%;}
.yui-gd div.first{width:32%;}
.yui-ge .yui-u{width:24%;}
.yui-ge div.first, 
.yui-gf .yui-u{width:74.2%;}
.yui-gf div.first{width:24%;}
.yui-ge div.first{width:74.2%;}
#bd:after,
.yui-g:after, 
.yui-gb:after, 
.yui-gc:after, 
.yui-gd:after, 
.yui-ge:after, 
.yui-gf:after{content:".";display:block;height:0;clear:both;visibility:hidden;}
#bd,
.yui-g, 
.yui-gb, 
.yui-gc, 
.yui-gd, 
.yui-ge, 
.yui-gf{zoom:1;}



#header{
	height:10%;
	background-color:#F3F2ED;
	margin:0;
	padding:0;
	}
	
#header h1{
	font-size: xx-large;
	text-align:center;
	margin:0;
	padding:10px;
	}
	
#header h2{
	font-size: x-large;
	text-align:center;
	margin:0;
	padding:10px;
	}
	
#header h1 a{
	color:#000000;
	background-color:#F3F2ED;
	}


.content{
	height:85%;
	background:#CCC8B3;
	border-top:#FFFFFF 2px solid;
	margin:0;
	padding:0;
	overflow: scroll;
	text-align:center;
	}

#secondary{
	height:85%;
	background:#F6F0E0;
	border-top:#FFFFFF 2px solid;
	margin:0;
	padding:0;
	}

#secondaryFull{
	height:50px;
	background-color:#CFB59F;
	border-top:#FFFFFF 2px solid;
	margin:0;
	padding:0;

	}

#footer{
	height:5%;
	background:#BFBD93;
	border-top:#FFFFFF 2px solid;
	margin:0;
	padding:0;
	


	text-transform: uppercase;
	font-size: medium;
	}
	</style>
</head>
<body>
<div id="doc3" class="yui-t3">
  <div id="hd">
    <div id="header"><h1>Siec zakladow pogrzebowych</h1><h2>Procentowy udzial w sprzedazy przez dany oddzial w danym roku</h2></div>
  </div>
  <div id="bd">
    <div id="yui-main">
      <div class="yui-b">
        <div class="content">
		<table border="1">
<tr>
<td>ID ODDZIALU</td>		<td>ID ROKU</td>		<td>ILOSC</td> <td>SUMA</td> <td>UDZIAL %</td></tr>

 ');
 FOR I IN (SELECT DISTINCT IdOddzialu ,IdRoku ,Ilosc,Sum(Ilosc ) over (PARTITION BY
IdProduktu) Sum_Ilosc, Round(100*Ilosc/(Sum(Ilosc) over (PARTITION
BY IdProduktu))) "UDZIAL" FROM p_sprzedaz
 ORDER BY IdOddzialu,IdRoku) LOOP 
htp.prn('
	<tr>
		<td>');
htp.prn( I.idODDZIALU );
htp.prn('      </td>    
		<td>');
htp.prn( I.idROKU );
htp.prn('      </td>    
		<td>');
htp.prn( I.ilosc);
htp.prn('      </td>  
		<td>');
htp.prn( I.SUM_ILOSC);
htp.prn('      </td> 
		<td>');
htp.prn( I.UDZIAL);
htp.prn('      </td>  
	</tr>
			
');
 END LOOP; 
htp.prn('
</table>
		</div>
      </div>
    </div>
    <div class="yui-b">
      <div id="secondary">
	  <ul>
	  <li><a href="CUBE1">CUBE1</a></li>
	  <li><a href="CUBE2">CUBE2</a></li>
	  <li><a href="ROLLUP1">ROLLUP1</a></li>
	  <li><a href="ROLLUP2">ROLLUP2</a></li>
	  <li><a href="OKNO1">OKNO PRZESUWNE 1</a></li>
	  <li><a href="OKNO2">OKNO PRZESUWNE 2</a></li>
	  <li><a href="GR1">GROUPING SETS 1</a></li>
	  <li><a href="GR2">GROUPING SETS 2</a></li>
	  <li><a href="PO1">PARTYCJE OBLICZENIOWE 1</a></li>
	  <li><a href="PO2">PARTYCJE OBLICZENIOWE 2</a></li>
	  <li><a href="GLOWNA">STRONA GLOWNA</a></li>
	  </ul>
	  </div>
    </div>
  </div>
  <div id="ft">
    <div id="footer"><center>Bazy danych 2 projekt, Sebastian Turlej Piotr Sadkowski 2ID13A</center></div>
  </div>
</div>
</body>
</html>
');
 END;
/

