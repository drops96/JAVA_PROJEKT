create PROCEDURE CUBE_1  AS 
 BEGIN NULL;
htp.prn('
');
htp.prn(' 
<html>
<body>

');
 END;
/

