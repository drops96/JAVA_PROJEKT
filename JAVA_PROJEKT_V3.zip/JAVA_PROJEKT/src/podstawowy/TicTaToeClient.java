package podstawowy;

import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.net.Socket;
import javax.swing.*;


public class TicTaToeClient {

    private JFrame frame = new JFrame("KÓŁKO KRZYŻYK");
    private JLabel messageLabel = new JLabel("");
    private static String nick;
    private ImageIcon icon;
    private ImageIcon opponentIcon;

    private Plansza[] board = new Plansza[9];
    private Plansza currentPlansza;

    private Socket socket;
    private BufferedReader in;
    private PrintWriter out;
    /**
     Tworzy socket i bufory potrzebne do obslugi rozgrywki, tworzy graficzna reprezentacje tablicy rozgrywki
     */
    private TicTaToeClient(String serverAddress) throws Exception {

        socket = new Socket(serverAddress, 8890);
        in = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        out = new PrintWriter(socket.getOutputStream(), true);

        messageLabel.setBackground(Color.lightGray);
        frame.getContentPane().add(messageLabel, "North");

        JPanel boardPanel = new JPanel();
        boardPanel.setBackground(Color.black);
        boardPanel.setLayout(new GridLayout(3, 3, 2, 2));

        for (int i = 0; i < board.length; i++) {
            final int j = i;
            board[i] = new Plansza();
            board[i].addMouseListener(new MouseAdapter() {
                public void mousePressed(MouseEvent e) {
                    currentPlansza = board[j];
                    out.println("MOVE " + j);
                }
            });
            boardPanel.add(board[i]);
        }

        frame.getContentPane().add(boardPanel, "Center");
    }


    /**
     Odpowiada za odebranie komunikatow i przetworzenie ich na konkretne instrukcje oraz zamkniecie socketu
     */
    private void play() throws Exception {
        String odpowiedz;
        try {
            odpowiedz = in.readLine();
            if (odpowiedz.startsWith("WITAJ")) {
                char mark = odpowiedz.charAt(6);

                icon = new ImageIcon(mark == 'X' ? "./res/x.png" : "./res/o.png");
                opponentIcon = new ImageIcon(mark == 'X' ? "./res/o.png" : "./res/x.png");
                frame.setTitle("KÓŁKO I KRZYŻYK - "+nick+" "+mark);

            }
            while (true) {
                odpowiedz = in.readLine();
                if (odpowiedz.startsWith("VALID_MOVE")) {
                    messageLabel.setText("Ruch dobry, czekaj na przeciwnika");
                    currentPlansza.ustawIkone(icon);
                    currentPlansza.repaint();
                } else if (odpowiedz.startsWith("OPPONENT_MOVED")) {
                    int loc = Integer.parseInt(odpowiedz.substring(15));
                    board[loc].ustawIkone(opponentIcon);
                    board[loc].repaint();
                    messageLabel.setText("Twoj ruch");
                } else if (odpowiedz.startsWith("VICTORY")) {
                    messageLabel.setText("Wygrana");
                    break;
                } else if (odpowiedz.startsWith("DEFEAT")) {
                    messageLabel.setText("Porazka");
                    break;
                } else if (odpowiedz.startsWith("TIE")) {
                    messageLabel.setText("Remis");
                    break;
                } else if (odpowiedz.startsWith("MESSAGE")) {
                    messageLabel.setText(odpowiedz.substring(8));
                }
            }
            out.println("KONIEC"+nick);


        } finally {

            socket.close();
        }
    }
    /**
     Sprawdza czy gracz chce powtorzyc rozgrywke
     */
    private boolean chcePonowic() {
        int odpowiedz = JOptionPane.showConfirmDialog(frame, "Wybierz czy zagrac ponownie", "Koniec gry!", JOptionPane.YES_NO_OPTION);
        frame.dispose();

        return odpowiedz == JOptionPane.YES_OPTION;
    }

    static class Plansza extends JPanel {
        JLabel label = new JLabel((Icon) null);

        Plansza() {
            setBackground(Color.white);
            add(label);
        }
        /**
         Odpowiada za ustawienie ikony gracza
         */
        void ustawIkone(Icon icon) {
            label.setIcon(icon);
        }
    }

    /**
     Tworzy polaczenie z serwerem na podstawie adresu, tworzy klienta i jego GUI
     */
    public static void main(String[] args) throws Exception {




        while (true) {
            String serverAddress;
            if (args.length == 0) {
                serverAddress = "localhost";
            } else {
                serverAddress = args[0];
            }
            nick=args[1];
            JFrame ramka = new JFrame();
            JOptionPane.showMessageDialog(ramka, "Twoj nick to: "+nick);

            TicTaToeClient client = new TicTaToeClient(serverAddress);
            client.frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
            client.frame.setSize(650, 650);
            client.frame.setVisible(true);
            client.frame.setResizable(false);
            client.play();


            if (!client.chcePonowic()) {

                break;
            }
        }
    }
}
